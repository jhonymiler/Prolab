
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `ativos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ativos` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `equipamento` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `modelo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fabricante` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ano` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `moeda` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sigla` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `valor` decimal(18,2) DEFAULT NULL,
  `valor_convertido` decimal(18,2) DEFAULT NULL,
  `vida_util` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `potencia` decimal(18,2) DEFAULT NULL,
  `horas` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dias` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `custo_manutencao` varchar(18) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `custo_pecas` varchar(18) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `afericao` tinyint(1) DEFAULT NULL,
  `depreciacao` decimal(18,2) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `ativos` WRITE;
/*!40000 ALTER TABLE `ativos` DISABLE KEYS */;
/*!40000 ALTER TABLE `ativos` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `centro_custos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `centro_custos` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `nome` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `centro_custos` WRITE;
/*!40000 ALTER TABLE `centro_custos` DISABLE KEYS */;
INSERT INTO `centro_custos` VALUES (1,'Laboratório',1,'2022-12-28 21:34:23','2022-12-28 21:34:23');
/*!40000 ALTER TABLE `centro_custos` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `clientes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `clientes` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `razao_social` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nome_fantasia` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cnpj` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `telefone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `celular` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `responsavel` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ie` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cep` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `rua` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `complemento` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `num` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bairro` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cidade` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `uf` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `clientes` WRITE;
/*!40000 ALTER TABLE `clientes` DISABLE KEYS */;
/*!40000 ALTER TABLE `clientes` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `custo_operacionais`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `custo_operacionais` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `descricao` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `medida_id` bigint unsigned NOT NULL,
  `valor` decimal(18,2) DEFAULT '0.00',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `observacao` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `custo_operacionais_medida_id_foreign` (`medida_id`),
  CONSTRAINT `custo_operacionais_medida_id_foreign` FOREIGN KEY (`medida_id`) REFERENCES `medidas` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `custo_operacionais` WRITE;
/*!40000 ALTER TABLE `custo_operacionais` DISABLE KEYS */;
INSERT INTO `custo_operacionais` VALUES (1,'Serviços Analises Terc. Labor. (Glicose)',19,7.00,1,NULL,'2023-01-13 16:49:22','2023-01-13 16:49:22'),(2,'Serviços Analises Terc. Labor. (Lactato)',19,14.00,1,NULL,'2023-01-13 16:49:22','2023-01-13 16:49:22'),(3,'Serviços Analises Terc. Labor. (Ureia)',19,7.00,1,NULL,'2023-01-13 16:49:22','2023-01-13 16:49:22'),(4,'Serviços Analises Terc. Labor. (Haptoglobulina)',19,100.00,1,NULL,'2023-01-13 16:49:22','2023-01-13 16:49:22'),(5,'Serviços Analises Terc. Labor. (Cerulo Plasmina)',19,100.00,1,NULL,'2023-01-13 16:49:22','2023-01-13 16:49:22'),(6,'Serviços Analises Terc. Labor. (Amido)',19,90.00,1,NULL,'2023-01-13 16:49:22','2023-01-13 16:49:22'),(7,'Serviços Analises Terc. Labor. EMBRAPA JAGUARIUNA',19,50.00,1,NULL,'2023-01-13 16:49:22','2023-01-13 16:49:22'),(8,'Serviços Analises Terc. Labor. (microbiota)',19,400.00,1,NULL,'2023-01-13 16:49:22','2023-01-13 16:49:22'),(9,'Serviços Analises Terc. Labor. (ALANTOINA)',19,21.00,1,NULL,'2023-01-13 16:49:22','2023-01-13 16:49:22'),(10,'Serviços Analises Terc. Labor. (CREATINA)',19,6.00,1,NULL,'2023-01-13 16:49:22','2023-01-13 16:49:22'),(11,'Serviços Analises Terc. Labor. (ACIDO URICO)',19,5.00,1,NULL,'2023-01-13 16:49:22','2023-01-13 16:49:22'),(12,'Serviços Analises Terc. Labor. (NITROGENIO TOTAL)',19,6.00,1,NULL,'2023-01-13 16:49:22','2023-01-13 16:49:22');
/*!40000 ALTER TABLE `custo_operacionais` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `energias`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `energias` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `data` date DEFAULT NULL,
  `consumo` decimal(18,2) DEFAULT '0.00',
  `valor` decimal(18,2) DEFAULT '0.00',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `energias` WRITE;
/*!40000 ALTER TABLE `energias` DISABLE KEYS */;
INSERT INTO `energias` VALUES (1,'2022-01-01',3692.00,2364.16,'2022-12-28 21:34:23','2022-12-28 21:34:23'),(2,'2022-02-01',1548.00,951.41,'2022-12-28 21:34:23','2022-12-28 21:34:23'),(3,'2022-03-01',6140.00,3703.00,'2022-12-28 21:34:23','2022-12-28 21:34:23'),(4,'2022-04-01',2087.00,1273.14,'2022-12-28 21:34:23','2022-12-28 21:34:23'),(5,'2022-05-01',5399.00,3414.00,'2022-12-28 21:34:23','2022-12-28 21:34:23'),(6,'2022-06-01',2611.00,1835.00,'2022-12-28 21:34:23','2022-12-28 21:34:23'),(7,'2022-07-01',2867.00,2047.09,'2022-12-28 21:34:23','2022-12-28 21:34:23'),(8,'2022-08-01',2990.00,2204.46,'2022-12-28 21:34:23','2022-12-28 21:34:23'),(9,'2022-09-01',1783.00,1783.00,'2022-12-28 21:34:23','2022-12-28 21:34:23'),(10,'2022-10-01',3190.00,3190.00,'2022-12-28 21:34:23','2022-12-28 21:34:23'),(11,'2022-11-01',2584.00,1693.67,'2022-12-28 21:34:23','2022-12-28 21:34:23');
/*!40000 ALTER TABLE `energias` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `fundacoes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fundacoes` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `nome` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `fundacoes` WRITE;
/*!40000 ALTER TABLE `fundacoes` DISABLE KEYS */;
INSERT INTO `fundacoes` VALUES (1,'FUNDEPAG',1,'2022-12-28 21:34:23','2022-12-28 21:34:23'),(2,'FUNDAG',1,'2022-12-28 21:34:23','2022-12-28 21:34:23'),(3,'FAPESP',1,'2022-12-28 21:34:23','2022-12-28 21:34:23');
/*!40000 ALTER TABLE `fundacoes` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `materiais`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `materiais` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `nome` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `medida_id` bigint unsigned NOT NULL,
  `valor` decimal(18,2) DEFAULT '0.00',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `observacao` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `materiais_medida_id_foreign` (`medida_id`),
  CONSTRAINT `materiais_medida_id_foreign` FOREIGN KEY (`medida_id`) REFERENCES `medidas` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `materiais` WRITE;
/*!40000 ALTER TABLE `materiais` DISABLE KEYS */;
/*!40000 ALTER TABLE `materiais` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `medidas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `medidas` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `nome` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sigla` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tipo` int NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `medidas` WRITE;
/*!40000 ALTER TABLE `medidas` DISABLE KEYS */;
INSERT INTO `medidas` VALUES (1,'Unidade','Un',1,'2022-12-28 21:34:23','2022-12-28 21:34:23'),(2,'Peça','pç',1,'2022-12-28 21:34:23','2022-12-28 21:34:23'),(3,'Kit','Kit',1,'2022-12-28 21:34:23','2022-12-28 21:34:23'),(4,'Mililitro','ml',2,'2022-12-28 21:34:23','2022-12-28 21:34:23'),(5,'Litro','L',2,'2022-12-28 21:34:23','2022-12-28 21:34:23'),(6,'Galão','Gl',2,'2022-12-28 21:34:23','2022-12-28 21:34:23'),(7,'Dose','Ds',2,'2022-12-28 21:34:23','2022-12-28 21:34:23'),(8,'Metro Cúbico','m³',2,'2022-12-28 21:34:23','2022-12-28 21:34:23'),(9,'Grama','g',3,'2022-12-28 21:34:23','2022-12-28 21:34:23'),(10,'Quilo','Kg',3,'2022-12-28 21:34:23','2022-12-28 21:34:23'),(11,'Tonelada','Ton',3,'2022-12-28 21:34:23','2022-12-28 21:34:23'),(12,'Milímetro','mm',4,'2022-12-28 21:34:23','2022-12-28 21:34:23'),(13,'Centímetro','cm',4,'2022-12-28 21:34:23','2022-12-28 21:34:23'),(14,'Metro','m',4,'2022-12-28 21:34:23','2022-12-28 21:34:23'),(15,'Quilômetro','Km',4,'2022-12-28 21:34:23','2022-12-28 21:34:23'),(16,'Watts','w',5,'2022-12-28 21:34:23','2022-12-28 21:34:23'),(17,'Quilowatts','Kw',5,'2022-12-28 21:34:23','2022-12-28 21:34:23'),(18,'Hora','Hr',6,'2022-12-28 21:34:23','2022-12-28 21:34:23'),(19,'Unidade','Un',1,'2023-01-13 16:49:08','2023-01-13 16:49:08'),(20,'Peça','pç',1,'2023-01-13 16:49:08','2023-01-13 16:49:08'),(21,'Kit','Kit',1,'2023-01-13 16:49:08','2023-01-13 16:49:08'),(22,'Mililitro','ml',2,'2023-01-13 16:49:08','2023-01-13 16:49:08'),(23,'Litro','L',2,'2023-01-13 16:49:08','2023-01-13 16:49:08'),(24,'Galão','Gl',2,'2023-01-13 16:49:08','2023-01-13 16:49:08'),(25,'Dose','Ds',2,'2023-01-13 16:49:08','2023-01-13 16:49:08'),(26,'Metro Cúbico','m³',2,'2023-01-13 16:49:08','2023-01-13 16:49:08'),(27,'Grama','g',3,'2023-01-13 16:49:08','2023-01-13 16:49:08'),(28,'Quilo','Kg',3,'2023-01-13 16:49:08','2023-01-13 16:49:08'),(29,'Tonelada','Ton',3,'2023-01-13 16:49:08','2023-01-13 16:49:08'),(30,'Milímetro','mm',4,'2023-01-13 16:49:08','2023-01-13 16:49:08'),(31,'Centímetro','cm',4,'2023-01-13 16:49:08','2023-01-13 16:49:08'),(32,'Metro','m',4,'2023-01-13 16:49:08','2023-01-13 16:49:08'),(33,'Quilômetro','Km',4,'2023-01-13 16:49:08','2023-01-13 16:49:08'),(34,'Watts','w',5,'2023-01-13 16:49:08','2023-01-13 16:49:08'),(35,'Quilowatts','Kw',5,'2023-01-13 16:49:08','2023-01-13 16:49:08'),(36,'Hora','Hr',6,'2023-01-13 16:49:08','2023-01-13 16:49:08'),(37,'Amostra','Am',2,'2023-01-13 16:49:08','2023-01-13 16:49:08');
/*!40000 ALTER TABLE `medidas` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2014_10_12_000000_create_users_table',1),(2,'2019_12_14_000001_create_personal_access_tokens_table',1),(3,'2022_11_03_214840_create_permission_tables',1),(4,'2022_11_15_200124_create_clientes_table',1),(5,'2022_11_15_201008_create_fundacaos_table',1),(6,'2022_11_15_201029_create_centro_custos_table',1),(7,'2022_11_15_201100_create_tipo_projetos_table',1),(8,'2022_11_15_201101_create_projetos_table',1),(9,'2022_11_15_212046_create_profissionals_table',1),(10,'2022_11_20_105904_create_ativos_table',1),(11,'2022_11_20_112625_create_energias_table',1),(12,'2022_12_18_134123_create_medidas_table',1),(13,'2022_12_18_134654_add_status_table_ativos',1),(14,'2022_12_18_185222_create_materiais_table',1),(15,'2023_01_09_193123_create_custo_operacionals_table',2),(16,'2023_01_09_193619_add_campo_observacao_tabela_materiais',2);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `model_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `model_has_permissions` (
  `permission_id` bigint unsigned NOT NULL,
  `model_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `model_has_permissions` WRITE;
/*!40000 ALTER TABLE `model_has_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `model_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `model_has_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `model_has_roles` (
  `role_id` bigint unsigned NOT NULL,
  `model_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `model_has_roles` WRITE;
/*!40000 ALTER TABLE `model_has_roles` DISABLE KEYS */;
INSERT INTO `model_has_roles` VALUES (3,'App\\Models\\User',1),(2,'App\\Models\\User',2),(1,'App\\Models\\User',3),(4,'App\\Models\\User',4);
/*!40000 ALTER TABLE `model_has_roles` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `permissions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `permissions_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB AUTO_INCREMENT=81 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
INSERT INTO `permissions` VALUES (1,'criar usuarios','web','2022-12-28 21:34:20','2022-12-28 21:34:20'),(2,'editar usuarios','web','2022-12-28 21:34:20','2022-12-28 21:34:20'),(3,'deletar usuarios','web','2022-12-28 21:34:20','2022-12-28 21:34:20'),(4,'ler usuarios','web','2022-12-28 21:34:20','2022-12-28 21:34:20'),(5,'criar materiais','web','2022-12-28 21:34:20','2022-12-28 21:34:20'),(6,'editar materiais','web','2022-12-28 21:34:20','2022-12-28 21:34:20'),(7,'deletar materiais','web','2022-12-28 21:34:20','2022-12-28 21:34:20'),(8,'ler materiais','web','2022-12-28 21:34:20','2022-12-28 21:34:20'),(9,'criar permissoes','web','2022-12-28 21:34:20','2022-12-28 21:34:20'),(10,'editar permissoes','web','2022-12-28 21:34:20','2022-12-28 21:34:20'),(11,'deletar permissoes','web','2022-12-28 21:34:21','2022-12-28 21:34:21'),(12,'ler permissoes','web','2022-12-28 21:34:21','2022-12-28 21:34:21'),(13,'criar niveis','web','2022-12-28 21:34:21','2022-12-28 21:34:21'),(14,'editar niveis','web','2022-12-28 21:34:21','2022-12-28 21:34:21'),(15,'deletar niveis','web','2022-12-28 21:34:21','2022-12-28 21:34:21'),(16,'ler niveis','web','2022-12-28 21:34:21','2022-12-28 21:34:21'),(17,'criar profissionais','web','2022-12-28 21:34:21','2022-12-28 21:34:21'),(18,'editar profissionais','web','2022-12-28 21:34:21','2022-12-28 21:34:21'),(19,'deletar profissionais','web','2022-12-28 21:34:21','2022-12-28 21:34:21'),(20,'ler profissionais','web','2022-12-28 21:34:21','2022-12-28 21:34:21'),(21,'criar orcamentos','web','2022-12-28 21:34:21','2022-12-28 21:34:21'),(22,'editar orcamentos','web','2022-12-28 21:34:21','2022-12-28 21:34:21'),(23,'deletar orcamentos','web','2022-12-28 21:34:21','2022-12-28 21:34:21'),(24,'ler orcamentos','web','2022-12-28 21:34:21','2022-12-28 21:34:21'),(25,'criar projetos','web','2022-12-28 21:34:21','2022-12-28 21:34:21'),(26,'editar projetos','web','2022-12-28 21:34:21','2022-12-28 21:34:21'),(27,'deletar projetos','web','2022-12-28 21:34:21','2022-12-28 21:34:21'),(28,'ler projetos','web','2022-12-28 21:34:21','2022-12-28 21:34:21'),(29,'criar configuracoes','web','2022-12-28 21:34:21','2022-12-28 21:34:21'),(30,'editar configuracoes','web','2022-12-28 21:34:21','2022-12-28 21:34:21'),(31,'deletar configuracoes','web','2022-12-28 21:34:21','2022-12-28 21:34:21'),(32,'ler configuracoes','web','2022-12-28 21:34:21','2022-12-28 21:34:21'),(33,'criar clientes','web','2022-12-28 21:34:21','2022-12-28 21:34:21'),(34,'editar clientes','web','2022-12-28 21:34:21','2022-12-28 21:34:21'),(35,'deletar clientes','web','2022-12-28 21:34:21','2022-12-28 21:34:21'),(36,'ler clientes','web','2022-12-28 21:34:21','2022-12-28 21:34:21'),(37,'criar ativos','web','2022-12-28 21:34:21','2022-12-28 21:34:21'),(38,'editar ativos','web','2022-12-28 21:34:21','2022-12-28 21:34:21'),(39,'deletar ativos','web','2022-12-28 21:34:21','2022-12-28 21:34:21'),(40,'ler ativos','web','2022-12-28 21:34:21','2022-12-28 21:34:21'),(41,'criar energia','web','2022-12-28 21:34:21','2022-12-28 21:34:21'),(42,'editar energia','web','2022-12-28 21:34:21','2022-12-28 21:34:21'),(43,'deletar energia','web','2022-12-28 21:34:21','2022-12-28 21:34:21'),(44,'ler energia','web','2022-12-28 21:34:21','2022-12-28 21:34:21'),(45,'criar km rodado','web','2022-12-28 21:34:21','2022-12-28 21:34:21'),(46,'editar km rodado','web','2022-12-28 21:34:21','2022-12-28 21:34:21'),(47,'deletar km rodado','web','2022-12-28 21:34:21','2022-12-28 21:34:21'),(48,'ler km rodado','web','2022-12-28 21:34:21','2022-12-28 21:34:21'),(49,'criar custos adm','web','2022-12-28 21:34:21','2022-12-28 21:34:21'),(50,'editar custos adm','web','2022-12-28 21:34:21','2022-12-28 21:34:21'),(51,'deletar custos adm','web','2022-12-28 21:34:21','2022-12-28 21:34:21'),(52,'ler custos adm','web','2022-12-28 21:34:21','2022-12-28 21:34:21'),(53,'criar custo condominio','web','2022-12-28 21:34:21','2022-12-28 21:34:21'),(54,'editar custo condominio','web','2022-12-28 21:34:21','2022-12-28 21:34:21'),(55,'deletar custo condominio','web','2022-12-28 21:34:21','2022-12-28 21:34:21'),(56,'ler custo condominio','web','2022-12-28 21:34:21','2022-12-28 21:34:21'),(57,'criar custos operacionais','web','2022-12-28 21:34:21','2022-12-28 21:34:21'),(58,'editar custos operacionais','web','2022-12-28 21:34:21','2022-12-28 21:34:21'),(59,'deletar custos operacionais','web','2022-12-28 21:34:21','2022-12-28 21:34:21'),(60,'ler custos operacionais','web','2022-12-28 21:34:21','2022-12-28 21:34:21'),(61,'criar entregaveis','web','2022-12-28 21:34:21','2022-12-28 21:34:21'),(62,'editar entregaveis','web','2022-12-28 21:34:21','2022-12-28 21:34:21'),(63,'deletar entregaveis','web','2022-12-28 21:34:21','2022-12-28 21:34:21'),(64,'ler entregaveis','web','2022-12-28 21:34:21','2022-12-28 21:34:21'),(65,'criar logistica','web','2022-12-28 21:34:21','2022-12-28 21:34:21'),(66,'editar logistica','web','2022-12-28 21:34:21','2022-12-28 21:34:21'),(67,'deletar logistica','web','2022-12-28 21:34:22','2022-12-28 21:34:22'),(68,'ler logistica','web','2022-12-28 21:34:22','2022-12-28 21:34:22'),(69,'criar materiais consumo','web','2022-12-28 21:34:22','2022-12-28 21:34:22'),(70,'editar materiais consumo','web','2022-12-28 21:34:22','2022-12-28 21:34:22'),(71,'deletar materiais consumo','web','2022-12-28 21:34:22','2022-12-28 21:34:22'),(72,'ler materiais consumo','web','2022-12-28 21:34:22','2022-12-28 21:34:22'),(73,'criar reagentes','web','2022-12-28 21:34:22','2022-12-28 21:34:22'),(74,'editar reagentes','web','2022-12-28 21:34:22','2022-12-28 21:34:22'),(75,'deletar reagentes','web','2022-12-28 21:34:22','2022-12-28 21:34:22'),(76,'ler reagentes','web','2022-12-28 21:34:22','2022-12-28 21:34:22'),(77,'criar ingredientes dieta','web','2022-12-28 21:34:22','2022-12-28 21:34:22'),(78,'editar ingredientes dieta','web','2022-12-28 21:34:22','2022-12-28 21:34:22'),(79,'deletar ingredientes dieta','web','2022-12-28 21:34:22','2022-12-28 21:34:22'),(80,'ler ingredientes dieta','web','2022-12-28 21:34:22','2022-12-28 21:34:22');
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `personal_access_tokens` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `profissionais`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `profissionais` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `cargo` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `valor_mercado` decimal(18,2) NOT NULL DEFAULT '0.00',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `profissionais` WRITE;
/*!40000 ALTER TABLE `profissionais` DISABLE KEYS */;
INSERT INTO `profissionais` VALUES (1,'Diretora',25000.00,1,'2022-12-28 21:34:23','2022-12-28 21:34:23'),(2,'Pesquisador Chefe',16000.00,1,'2022-12-28 21:34:23','2022-12-28 21:34:23'),(3,'Coordenador',8000.00,1,'2022-12-28 21:34:23','2022-12-28 21:34:23'),(4,'Assistente de Laboratorio',4000.00,1,'2022-12-28 21:34:23','2022-12-28 21:34:23'),(5,'Faxineira',1500.00,1,'2022-12-28 21:34:23','2022-12-28 21:34:23'),(6,'Estagiário',2000.00,1,'2022-12-28 21:34:23','2022-12-28 21:34:23'),(7,'Tratorista',2000.00,1,'2022-12-28 21:34:23','2022-12-28 21:34:23'),(8,'Tratador',2000.00,1,'2022-12-28 21:34:23','2022-12-28 21:34:23');
/*!40000 ALTER TABLE `profissionais` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `projetos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `projetos` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `num_contrato` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nome` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fundacao_id` bigint unsigned NOT NULL,
  `cliente_id` bigint unsigned NOT NULL,
  `data_termino` datetime DEFAULT NULL,
  `tipo_projetos_id` bigint unsigned NOT NULL,
  `valor_contrato` decimal(8,2) NOT NULL,
  `valor_aditivos` decimal(8,2) NOT NULL DEFAULT '0.00',
  `valor_recebido` decimal(8,2) NOT NULL DEFAULT '0.00',
  `valor_receber` decimal(8,2) NOT NULL,
  `valor_gasto` decimal(8,2) NOT NULL,
  `status` enum('0','1','2','3') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `porc_conclusao` decimal(8,2) DEFAULT NULL,
  `prazo` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `projetos_fundacao_id_foreign` (`fundacao_id`),
  KEY `projetos_cliente_id_foreign` (`cliente_id`),
  KEY `projetos_tipo_projetos_id_foreign` (`tipo_projetos_id`),
  CONSTRAINT `projetos_cliente_id_foreign` FOREIGN KEY (`cliente_id`) REFERENCES `clientes` (`id`),
  CONSTRAINT `projetos_fundacao_id_foreign` FOREIGN KEY (`fundacao_id`) REFERENCES `fundacoes` (`id`),
  CONSTRAINT `projetos_tipo_projetos_id_foreign` FOREIGN KEY (`tipo_projetos_id`) REFERENCES `tipo_projetos` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `projetos` WRITE;
/*!40000 ALTER TABLE `projetos` DISABLE KEYS */;
/*!40000 ALTER TABLE `projetos` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `role_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `role_has_permissions` (
  `permission_id` bigint unsigned NOT NULL,
  `role_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`role_id`),
  KEY `role_has_permissions_role_id_foreign` (`role_id`),
  CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `role_has_permissions` WRITE;
/*!40000 ALTER TABLE `role_has_permissions` DISABLE KEYS */;
INSERT INTO `role_has_permissions` VALUES (1,1),(2,1),(3,1),(4,1),(5,1),(6,1),(7,1),(8,1),(9,1),(10,1),(11,1),(12,1),(13,1),(14,1),(15,1),(16,1),(17,1),(18,1),(19,1),(20,1),(21,1),(22,1),(23,1),(24,1),(25,1),(26,1),(27,1),(28,1),(29,1),(30,1),(31,1),(32,1),(33,1),(34,1),(35,1),(36,1),(37,1),(38,1),(39,1),(40,1),(41,1),(42,1),(43,1),(44,1),(45,1),(46,1),(47,1),(48,1),(49,1),(50,1),(51,1),(52,1),(53,1),(54,1),(55,1),(56,1),(57,1),(58,1),(59,1),(60,1),(61,1),(62,1),(63,1),(64,1),(65,1),(66,1),(67,1),(68,1),(69,1),(70,1),(71,1),(72,1),(73,1),(74,1),(75,1),(76,1),(77,1),(78,1),(79,1),(80,1),(1,2),(2,2),(3,2),(4,2),(5,2),(6,2),(7,2),(8,2),(9,2),(10,2),(11,2),(12,2),(13,2),(14,2),(15,2),(16,2),(17,2),(18,2),(19,2),(20,2),(21,2),(22,2),(23,2),(24,2),(25,2),(26,2),(27,2),(28,2),(29,2),(30,2),(31,2),(32,2),(33,2),(34,2),(35,2),(36,2),(37,2),(38,2),(39,2),(40,2),(41,2),(42,2),(43,2),(44,2),(45,2),(46,2),(47,2),(48,2),(49,2),(50,2),(51,2),(52,2),(53,2),(54,2),(55,2),(56,2),(57,2),(58,2),(59,2),(60,2),(61,2),(62,2),(63,2),(64,2),(65,2),(66,2),(67,2),(68,2),(69,2),(70,2),(71,2),(72,2),(73,2),(74,2),(75,2),(76,2),(77,2),(78,2),(79,2),(80,2),(1,3),(2,3),(3,3),(4,3),(5,3),(6,3),(7,3),(8,3),(9,3),(10,3),(11,3),(12,3),(13,3),(14,3),(15,3),(16,3),(17,3),(18,3),(19,3),(20,3),(21,3),(22,3),(23,3),(24,3),(25,3),(26,3),(27,3),(28,3),(29,3),(30,3),(31,3),(32,3),(33,3),(34,3),(35,3),(36,3),(37,3),(38,3),(39,3),(40,3),(41,3),(42,3),(43,3),(44,3),(45,3),(46,3),(47,3),(48,3),(49,3),(50,3),(51,3),(52,3),(53,3),(54,3),(55,3),(56,3),(57,3),(58,3),(59,3),(60,3),(61,3),(62,3),(63,3),(64,3),(65,3),(66,3),(67,3),(68,3),(69,3),(70,3),(71,3),(72,3),(73,3),(74,3),(75,3),(76,3),(77,3),(78,3),(79,3),(80,3);
/*!40000 ALTER TABLE `role_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roles_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'Administrador','web','2022-12-28 21:34:22','2022-12-28 21:34:22'),(2,'Gestor','web','2022-12-28 21:34:22','2022-12-28 21:34:22'),(3,'Usuario','web','2022-12-28 21:34:22','2022-12-28 21:34:22'),(4,'Super-Admin','web','2022-12-28 21:34:22','2022-12-28 21:34:22');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `tipo_projetos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tipo_projetos` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `nome` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `tipo_projetos` WRITE;
/*!40000 ALTER TABLE `tipo_projetos` DISABLE KEYS */;
INSERT INTO `tipo_projetos` VALUES (1,'Confinamento Baia Coletiva',1,'2022-12-28 21:34:23','2022-12-28 21:34:23'),(2,'Confinamento Baia Individual',1,'2022-12-28 21:34:23','2022-12-28 21:34:23'),(3,'Confinamento Integrado',1,'2022-12-28 21:34:23','2022-12-28 21:34:23'),(4,'Dual Flow',1,'2022-12-28 21:34:23','2022-12-28 21:34:23'),(5,'Dual Flow + Prod. Gas Amkom',1,'2022-12-28 21:34:23','2022-12-28 21:34:23'),(6,'Experimento In Situ',1,'2022-12-28 21:34:23','2022-12-28 21:34:23'),(7,'In Vitro Digestibilidade Intestinal',1,'2022-12-28 21:34:23','2022-12-28 21:34:23'),(8,'Prod de Gás Ankom',1,'2022-12-28 21:34:23','2022-12-28 21:34:23');
/*!40000 ALTER TABLE `tipo_projetos` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `celular` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `avatar` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'avatar.jpg',
  `status` tinyint(1) DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Usuário','user@teste.com','651.883.6490','avatar.jpg',1,'2022-12-28 21:34:22','$2y$10$3w7Yx15Pq4GYAJj01uiz..a866bm2cu/J6MBWv7FH9QgEwoXZ9DwK','eDxFtbaqRX','2022-12-28 21:34:22','2022-12-28 21:34:22'),(2,'Gestor do sistema','gestor@teste.com','+1 (831) 988-7190','avatar.jpg',1,'2022-12-28 21:34:23','$2y$10$g4fRSxn567BJCfaSLKZEIuMVpxAt0KoRi6lHJSxjSYbv3rzLtJBBq','pE0Yqm6v2K','2022-12-28 21:34:23','2022-12-28 21:34:23'),(3,'Administrador','admin@teste.com','669.501.1528','avatar.jpg',1,'2022-12-28 21:34:23','$2y$10$96x8UXrqPJlFfdFdTZ8JkelVtKStw1eowN8L3vf8sMyLnUgM1QPWy','fOtpvJOGSU','2022-12-28 21:34:23','2022-12-28 21:34:23'),(4,'Jonatas Miler','jonatasmiler@gmail.com','1-657-497-1037','avatar.jpg',1,'2022-12-28 21:34:23','$2y$10$AlLpa0mbL6AM.XFxAHVG3.ya5tJkXMtpxIITQWhgUoU37VsmB2dWi','xiPfBC5Iqm','2022-12-28 21:34:23','2022-12-28 21:34:23');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

